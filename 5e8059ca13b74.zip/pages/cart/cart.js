// pages/cart/cart.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isBlank: true,
    guessList: [
      {
        id: 1,
        img: "//img11.360buyimg.com/babel/s340x360_jfs/t21385/236/196190262/81424/c5f3e5c1/5b0283a3N9a4b2ff2.png!q90!cc_170x180",
        title: "一加6双摄游戏手机一加6双摄游戏手机一加6双摄游戏手机",
        price: "3999",
        sold: "1258"
      },
      {
        id: 2,
        img: "//img12.360buyimg.com/babel/s340x360_jfs/t21649/277/1903330169/60235/2c6a929c/5b3c6526Nc866b521.jpg!q90!cc_170x180",
        title: "一加6双摄游戏手机",
        price: "3999",
        sold: "1258"
      },
      {
        id: 3,
        img: "//img10.360buyimg.com/babel/s340x360_jfs/t21928/110/1872308896/62608/8676354a/5b3b1aa4Na4d1e41b.jpg!q90!cc_170x180",
        title: "一加6双摄游戏手机",
        price: "3999",
        sold: "1258"
      },
      {
        id: 4,
        img: "//img12.360buyimg.com/babel/s340x360_jfs/t19966/269/2119043596/48780/dbfd7ab0/5b31fb2fN11ee4b7c.jpg!q90!cc_170x180",
        title: "一加6双摄游戏手机一加6双摄游戏手机一加6双摄游戏手机",
        price: "3999",
        sold: "1258"
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})